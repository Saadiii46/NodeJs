// let msg = "Hello world";
// console.log(msg);

// const fs = require('fs');
// fs.writeFileSync('File.txt', 'Hello class!');

// const readline = require('readline');
// const rl = readline.createInterface({input: process.stdin,output: process.stdout,});
// rl.question("What is your name?", function(ans){
//     console.log(`Your  name is ${ans}`);
//     rl.close();
// });


const prompt = require('prompt-sync')();
const input = prompt("What is your name?");
console.log(`Your name is ${input}`);